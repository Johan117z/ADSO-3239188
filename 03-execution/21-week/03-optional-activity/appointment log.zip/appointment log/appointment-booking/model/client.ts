// Mirrors the "client" table of the database
export interface Client {
  id: number;
  typeDocument: string;
  document: string;
  name: string;
  address: string;
  phone: string;
  email: string;
}
