// Mirrors the "reservation" table of the database
export interface Reservation {
  id: number;
  name: string;
  description: string;
  clientId: number; // Foreign key -> Client.id
}
