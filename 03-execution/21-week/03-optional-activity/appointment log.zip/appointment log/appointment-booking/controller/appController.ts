import type { Client } from "../model/client.js";
import type { Reservation } from "../model/reservation.js";

// Business logic: in-memory "tables" + validations
export class AppController {
  private clients: Client[] = [];
  private reservations: Reservation[] = [];
  private nextClientId = 1;
  private nextReservationId = 1;

  // ---------- CLIENT ----------
  createClient(data: Omit<Client, "id">): Client {
    if (!data.typeDocument || !data.document.trim() || !data.name.trim() ||
        !data.address.trim() || !data.phone.trim() || !data.email.trim()) {
      throw new Error("Todos los campos del cliente son obligatorios.");
    }
    if (!data.email.includes("@")) {
      throw new Error("El correo electrónico no es válido.");
    }
    if (this.clients.some(c => c.document === data.document)) {
      throw new Error("Ya existe un cliente con ese documento.");
    }
    const client: Client = { id: this.nextClientId++, ...data };
    this.clients.push(client);
    return client;
  }

  getClients(): Client[] {
    return this.clients;
  }

  deleteClient(id: number): void {
    if (this.reservations.some(r => r.clientId === id)) {
      throw new Error("No se puede eliminar un cliente que tiene reservas.");
    }
    this.clients = this.clients.filter(c => c.id !== id);
  }

  // ---------- RESERVATION ----------
  createReservation(data: Omit<Reservation, "id">): Reservation {
    if (!data.name.trim() || !data.description.trim()) {
      throw new Error("El nombre y la descripción de la reserva son obligatorios.");
    }
    // Key rule: the client must exist before creating a reservation
    if (!this.clients.some(c => c.id === data.clientId)) {
      throw new Error("El cliente seleccionado no existe.");
    }
    const reservation: Reservation = { id: this.nextReservationId++, ...data };
    this.reservations.push(reservation);
    return reservation;
  }

  getReservations(): Reservation[] {
    return this.reservations;
  }

  deleteReservation(id: number): void {
    this.reservations = this.reservations.filter(r => r.id !== id);
  }

  getClientName(clientId: number): string {
    return this.clients.find(c => c.id === clientId)?.name ?? "Desconocido";
  }
}
