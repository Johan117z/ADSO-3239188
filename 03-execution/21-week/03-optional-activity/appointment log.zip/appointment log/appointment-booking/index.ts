import { AppController } from "./controller/appController.js";

const controller = new AppController();

// ---------- DOM helpers ----------
const getInput = (id: string) =>
  document.getElementById(id) as HTMLInputElement;

const clientForm = document.getElementById("client-form") as HTMLFormElement;
const reservationForm = document.getElementById("reservation-form") as HTMLFormElement;
const clientList = document.getElementById("client-list") as HTMLUListElement;
const reservationList = document.getElementById("reservation-list") as HTMLUListElement;
const clientSelect = document.getElementById("reservation-client") as HTMLSelectElement;

// ---------- UI builders ----------
function createItem(title: string, details: string): HTMLLIElement {
  const li = document.createElement("li");
  li.className = "item";

  const info = document.createElement("div");
  const strong = document.createElement("strong");
  strong.textContent = title;
  const small = document.createElement("small");
  small.textContent = details;
  info.append(strong, small);

  li.appendChild(info);
  return li;
}

function createEmptyMessage(text: string): HTMLLIElement {
  const li = document.createElement("li");
  li.className = "empty";
  li.textContent = text;
  return li;
}

// ---------- Render (updates the view from controller data) ----------
function renderClients(): void {
  clientList.innerHTML = "";
  clientSelect.innerHTML = '<option value="">Selecciona un cliente</option>';

  const clients = controller.getClients();
  if (clients.length === 0) {
    clientList.appendChild(createEmptyMessage("Aún no hay clientes registrados."));
  }

  for (const client of clients) {
    const li = createItem(
      client.name,
      `${client.typeDocument} ${client.document} · ${client.phone} · ${client.email}`
    );

    const deleteButton = document.createElement("button");
    deleteButton.className = "btn-delete";
    deleteButton.textContent = "Eliminar";
    deleteButton.addEventListener("click", () => {
      try {
        controller.deleteClient(client.id);
        renderAll();
      } catch (error) {
        alert((error as Error).message);
      }
    });
    li.appendChild(deleteButton);
    clientList.appendChild(li);

    const option = document.createElement("option");
    option.value = String(client.id);
    option.textContent = client.name;
    clientSelect.appendChild(option);
  }
}

function renderReservations(): void {
  reservationList.innerHTML = "";

  const reservations = controller.getReservations();
  if (reservations.length === 0) {
    reservationList.appendChild(createEmptyMessage("Aún no hay citas agendadas."));
  }

  for (const reservation of reservations) {
    const li = createItem(
      reservation.name,
      `${reservation.description} · Cliente: ${controller.getClientName(reservation.clientId)}`
    );

    const deleteButton = document.createElement("button");
    deleteButton.className = "btn-delete";
    deleteButton.textContent = "Eliminar";
    deleteButton.addEventListener("click", () => {
      controller.deleteReservation(reservation.id);
      renderAll();
    });
    li.appendChild(deleteButton);
    reservationList.appendChild(li);
  }
}

function renderAll(): void {
  renderClients();
  renderReservations();
}

// ---------- Events (connect View -> Controller) ----------
clientForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    controller.createClient({
      typeDocument: getInput("client-type-document").value,
      document: getInput("client-document").value,
      name: getInput("client-name").value,
      address: getInput("client-address").value,
      phone: getInput("client-phone").value,
      email: getInput("client-email").value,
    });
    clientForm.reset();
    renderAll();
    alert("Cliente agregado correctamente.");
  } catch (error) {
    alert((error as Error).message);
  }
});

reservationForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    controller.createReservation({
      name: getInput("reservation-name").value,
      description: getInput("reservation-description").value,
      clientId: Number(clientSelect.value),
    });
    reservationForm.reset();
    renderAll();
    alert("Cita agendada correctamente.");
  } catch (error) {
    alert((error as Error).message);
  }
});

renderAll();
